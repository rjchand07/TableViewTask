//
//  FourthCell.swift
//  Medical_Reports
//
//  Created by ekincare on 13/12/21.
//

import UIKit

class FourthCell: UITableViewCell {

    static let identifier = "FourthCell"
    static func nib() -> UINib {
        return UINib(nibName: "FourthCell", bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
