//
//  BlackCell.swift
//  Medical_Reports
//
//  Created by ekincare on 13/12/21.
//

import UIKit

class BlackCell: UITableViewCell {

    @IBOutlet weak var customView: UIView!
    static let identifier = "BlackCell"
    static func nib() -> UINib {
        return UINib(nibName: "BlackCell", bundle: nil)
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        self.customView.backgroundColor = UIColor(red: 0.898, green: 0.898, blue: 0.898, alpha: 1)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
