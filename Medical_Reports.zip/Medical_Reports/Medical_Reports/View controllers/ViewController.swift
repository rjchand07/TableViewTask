//
//  ViewController.swift
//  Medical_Reports
//
//  Created by ekincare on 13/12/21.
//

import UIKit

class ViewController: UIViewController {
    
    var selectedIndex = IndexPath()
    var isSelected: Bool = false
    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableview.delegate = self
        tableview.dataSource = self
        tableview.rowHeight = UITableView.automaticDimension
        tableview.estimatedRowHeight = 350
        
        regCell()
    }
    
    func regCell() {
        self.tableview.register(BlackCell.nib(), forCellReuseIdentifier: BlackCell.identifier)
        self.tableview.register(FirstCell.nib(), forCellReuseIdentifier: FirstCell.identifier)
        self.tableview.register(SecondCell.nib(), forCellReuseIdentifier: SecondCell.identifier)
        self.tableview.register(ThirdCell.nib(), forCellReuseIdentifier: ThirdCell.identifier)
        self.tableview.register(FourthCell.nib(), forCellReuseIdentifier: FourthCell.identifier)
        self.tableview.register(FifthCell.nib(), forCellReuseIdentifier: FifthCell.identifier)
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.row {
        case 0:
            return 337
        case 1:
            return 20
        case 2:
            if self.selectedIndex == indexPath && isSelected == true {
                return 188
            } else {
                return 66
            }
        case 3:
            return 56
        case 4:
            return 56
        default:
            return UITableView.automaticDimension
        }
    }
}

extension ViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cellSetup(indexPath: indexPath)
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 2 {
            if selectedIndex == indexPath {
                if isSelected == false {
                    self.isSelected = true
                    if let cell = tableView.cellForRow(at: indexPath) as? ThirdCell {
                        cell.animate()
                    }
                } else {
                    self.isSelected = false
                }
            } else {
                self.isSelected = true
            }
            self.selectedIndex = indexPath
            UIView.animate(withDuration: 0.3) {
                self.tableview.performBatchUpdates(nil)
            }
        }
        tableView.deselectRow(at: indexPath, animated: false)
    }
    
    func cellSetup(indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0:
            if let cell = tableview.dequeueReusableCell(withIdentifier: "FirstCell", for: indexPath) as? FirstCell {
                cell.setupChart()
                cell.setChartValues(10)
                return cell
            }
        case 1:
            if let cell = tableview.dequeueReusableCell(withIdentifier: "SecondCell", for: indexPath) as? SecondCell {
                return cell
            }
        case 2:
            if let cell = tableview.dequeueReusableCell(withIdentifier: "ThirdCell", for: indexPath) as? ThirdCell {
                return cell
            }
        case 3:
            if let cell = tableview.dequeueReusableCell(withIdentifier: "FourthCell", for: indexPath) as? FourthCell {
                return cell
            }
        case 4:
            if let cell = tableview.dequeueReusableCell(withIdentifier: "FifthCell", for: indexPath) as? FifthCell {
                
                return cell
            }
        default:
            return UITableViewCell()
        }
       
        return UITableViewCell()
    }
    
    
}










//        if selectedIndex == indexPath.row {
//            if self.isSelected == false {
//                self.isSelected = true
//            }else {
//                self.isSelected = false
//            }
//        } else {
//            self.isSelected = true
//        }
//        self.selectedIndex = indexPath.row
//        tableView.reloadRows(at: [indexPath], with: .automatic)


